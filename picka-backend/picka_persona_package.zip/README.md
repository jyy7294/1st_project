# 픽카(PickCa) 페르소나 가상 데이터 — 개발자 연동 가이드

발표용 4개 페르소나의 프로필/아바타/카드내역(2026년 6월 한 달치) 데이터입니다.

## 파일 구조

```
picka/
├── data/
│   ├── personas_index.json   # 로그인 분기용 인덱스 (테스트 계정 포함)
│   ├── persona1.json         # 20대 여성 대학생 (김서연)
│   ├── persona2.json         # 30대 남성 직장인 (박준혁)
│   ├── persona3.json         # 30대 신혼부부+영유아 (이지훈·최민아)
│   └── persona4.json         # 40대 여성 주부 (정은주)
└── preview.html              # 발표/검수용 미리보기 페이지
```

## 로그인 분기 (personas_index.json)

테스트 계정으로 로그인 → personaId 매칭 → 해당 JSON을 로드하는 구조입니다.

| loginId | password | 페르소나 |
|---|---|---|
| persona1@picka.app | picka1234 | 20대 여성 대학생 |
| persona2@picka.app | picka1234 | 30대 남성 직장인 |
| persona3@picka.app | picka1234 | 30대 신혼부부(영유아) |
| persona4@picka.app | picka1234 | 40대 여성 주부 |

```js
// 예시: 로그인 후 페르소나 데이터 로드
const index = await fetch('/data/personas_index.json').then(r => r.json());
const persona = index.personas.find(p => p.loginId === loginId);
const data = await fetch('/' + persona.dataFile).then(r => r.json());
// data.profile, data.transactions, data.summary 사용
```

## persona{n}.json 스키마

```jsonc
{
  "personaId": "persona1",
  "profile": {
    "name": "김서연", "age": 23, "gender": "여성", "job": "대학생(4학년)",
    "residence": "...",
    "description": "소비 성향 요약",
    "monthlyBudget": 900000,
    "recommendPoint": "카드 추천 로직에 쓸 핵심 혜택 포인트"
  },
  "cards": [ { "cardName": "...", "cardType": "체크|신용", "last4": "1234" } ],
  "transactions": [
    {
      "id": "persona1-001",
      "date": "2026-06-01",        // YYYY-MM-DD
      "time": "10:15",             // HH:mm
      "merchant": "가맹점명",
      "category": "대분류",         // 예: 식비, 교통, 육아, 교육 ...
      "subCategory": "소분류",      // 예: 배달, 주유, 학원비 ...
      "amount": 23000,             // 원 단위 정수
      "paymentMethod": "신용카드 | 체크카드 | 자동이체",
      "memo": ""
    }
  ],
  "summary": {
    "period": "2026-06",
    "totalSpend": 2563300,
    "transactionCount": 62,
    "byCategory": [ { "category": "교육", "amount": 1386500, "ratio": 54.1 } ], // 금액 내림차순
    "topCategory": "교육"
  }
}
```

- `transactions`는 날짜/시간 오름차순 정렬 상태
- `summary`는 프론트에서 재계산 없이 바로 차트/도넛그래프에 사용 가능
- 카테고리 체계는 페르소나별 소비 특성에 맞춰 다르게 구성됨 (필요 시 공통 코드로 매핑)

## 페르소나별 데이터 특징 (카드 추천 근거)

| | 총지출(6월) | 건수 | 1위 카테고리 | 소비 시그니처 |
|---|---|---|---|---|
| P1 대학생 | 2,563,300원 | 62건 | 교육(등록금 분납 포함) | 온라인쇼핑·카페·배달·편의점 다건 소액, 대중교통 |
| P2 직장인 | 1,612,090원 | 55건 | 식비 | 헬스/PT, 주유+택시, 닭가슴살 정기구매, 주1회 술자리 |
| P3 신혼부부 | 3,793,000원 | 35건 | 주거(대출 142만) | 기저귀·분유 정기구매, 소아과, 마트 장보기, 보험 3건 |
| P4 주부 | 2,992,790원 | 41건 | 식비/생활 | 학원비 98만 고정, 마트+쿠팡·컬리 병행, 병원·보험 |
